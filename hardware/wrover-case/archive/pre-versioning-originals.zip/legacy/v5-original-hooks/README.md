# WROVER anchor case — V5 internal-lip closure

**Two PLA prints, no assembly hardware. Print a matching V5 base and lid.**

Physical feedback on V4: the board seats well on its pegs and the four flexible
pillar supports hold it down well, but the external latches are too easily
overcome and allow excessive lid movement. V5 preserves the peg and PCB spring
dimensions and replaces the closure.

The lid now has a **4 mm deep internal locating lip**, interrupted at the USB
opening and at two catch tongues. The lip locates the lid in both horizontal
axes. Two wide internal hooks engage underneath shoulders in the base walls.
The tongues flex inward during closing; once engaged, their flat shoulders
carry the upward board-spring load against the case walls. There are no
external flexible arms or projecting release ears.

**V5 has passed the CAD checks below, but the new closure has not been physically
tested. Try the small closure sample first.** In particular, closing effort,
printed hook engagement, release effort, and repeat-use durability need an
actual PLA print. Geometric checks do not establish those properties.

## Files

- `exports/base-v5-internal-lip.stl`: base with the proven pegs and new catches.
- `exports/lid-v5-internal-snap.stl`: internal lip, hooks and unchanged PCB springs.
- `exports/test-base-v5-closure.stl` and `exports/test-lid-v5-closure.stl`:
  **22 mm central strips of the real parts**, including both catches and side lips.
- `exports/wrover-case-v5-internal-lip.zip`: source, main STLs, samples and instructions.
- `exports/base.stl`, `lid.stl`, `test_base.stl`, `test_lid.stl`: current V5 aliases.
- `exports/fitcheck.stl`: low tray with the V5 footprint and existing peg pattern.
- `wrover-case.scad`: editable source; opens in print layout.
- `exports/layout.png`, `assembled.png`, `exploded.png`: current previews.
- `legacy/v4-external-clips/`: archived V4 source, instructions and named STLs.
  Older named exports remain available for existing links; use V5 for this revision.

The body is **86 × 46.6 × 17.6 mm**, plus up to 0.3 mm lid lift under spring
pressure. Length and body width increased by 4 mm to give the locating lip
room without bridging or stiffening the working PCB springs. Overall width
is smaller than V4 including its external release ears. The PCB hole pitch,
support height, locator dimensions and PCB springs are unchanged.

## Printing and trying the closure

1. Start with `test-base-v5-closure.stl` and `test-lid-v5-closure.stl`. Print in
   their supplied orientations with plain PLA, 0.2 mm layers, a 0.4 mm nozzle,
   3 perimeters and about 20% infill. Thin tongues and springs should be solid.
   Keep brims and strings clear of the slots.
2. Both clips should engage when you push the sample halves together. Check
   that a gentle upward pull does not release them without pressing the tongues.
   The side lips should constrain sideways play. The sample's open ends do
   **not** test lengthwise location or PCB pressure; those need the full case.
3. Release by pressing each tongue **inward through its side window**, using a
   fingernail or flat plastic tool, while lifting that edge slightly. Then
   release the other side. Do not simply yank the lid upwards. No tool or
   hardware remains inside the case.
4. If the sample closes and holds satisfactorily, print both full V5 parts in
   their supplied orientations: base floor down, lid exterior face down with
   its pillars and catches pointing upwards. Designed for no supports. Inspect
   the 13.6 mm window roof bridges and the 0.85 mm hook overhangs in the slicer;
   remove sagging strands that obstruct a catch.
5. Unplug the board and lower it component-side up onto the pegs, USB at the
   opening. It should rest flat on all four supports as with V4.
6. Put the lid's button holes at the USB end. Lower it vertically, align the
   internal lip and press near the catches until both engage. The pillar pads
   press on the PCB around the holes, using the same flexible leaves as V4.
7. Check lid retention and movement, then gently shake the case with the USB
   cable disconnected to check for board rattle. Recheck after it has been
   closed for a day; sustained flex in PLA can relax. Check USB/button access
   and ranging performance with the case closed.

## Geometry and adjustment

The locating lip has 0.25 mm nominal clearance on each side and is 1.2 mm thick.
It fits independently of the two catch tongues. Those tongues are 12 mm wide,
1 mm thick and have 10.2 mm from lid underside to retaining shoulder. Each hook
engages 0.6 mm into the base wall. The windows also provide access for release.

The four PCB leaves remain 20 mm from root to pad centre, 6.6 mm wide and 1.2 mm
thick. The unchanged free pad reach is 0.9 mm beyond the nominal PCB top. The
closure retains 0.3 mm vertical clearance, leaving the same **0.6 mm nominal
PCB spring deflection** as V4. STL and assembled previews show the unloaded
spring shape, so intentional pad/PCB overlap is not a rigid interference error.

Only tune the closure parameters if the sample needs adjustment:

- `alignment_clearance`: per-side lip clearance, controlling lateral fit.
- `clip_engagement`: retaining overlap and insertion deflection.
- `clip_thickness`: tongue stiffness; increasing it also raises bending strain.
- `clip_window_clearance`: lengthwise clearance around the hooks.

Do not scale the STLs globally; that changes the confirmed board hole pattern.
Preserve `board_preload`, `clip_lift_clearance` and the PCB spring geometry unless
there is new feedback about board retention. Changing the latter clearance also
changes board spring loading.

## Verification performed

OpenSCAD 2021.01 rendered the base, lid, low tray and both closure samples.
`verify_meshes.py` verified all five as single closed manifold shells with
consistent winding, positive volume and their lowest point at Z=0.
The V4 and V5 PCB/pin/spring parameters and three spring modules were compared:
all are unchanged. The increased edge gap translates their positions together.

`verify_geometry.scad` checks actual CSG geometry:

- No base/lid interference in the closed position, including pin/socket clearance.
- Clear rigid insertion path sampled every 1 mm over 16 mm of travel, excluding
  the tongues which intentionally flex.
- No collision with the approximate above-PCB component envelopes.
- Both hooks catch when lifted 0.2 mm beyond the intended latch clearance.
- A 1.2 mm inward displacement of the tongues clears the base and PCB along the
  sampled release path. This is a clearance envelope, not a deformation model.
- The lip alone hits stops in both positive and negative X and Y directions at
  0.4 mm displacement; it remains clear at the four combinations of ±0.2 mm X/Y.

Strength, force, fatigue and creep are not established by these geometric checks.

## Dimension sources and cross-validation

The [Makerfabs DW3000 hardware directory](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/tree/main/hardware)
contains the [Eagle board](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.brd)
and an [electrical schematic PDF](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.pdf).
Mechanical dimensions come from the board file's layer 20, not the electrical
schematic or the dimensions of the WROVER module alone.

| Feature | Published CAD dimension |
| --- | --- |
| PCB outline | 72 × 32.6 mm |
| Mounting-hole centres | (2, 2), (70, 2), (70, 30.6), (2, 30.6) mm |
| Mounting-hole pitch | 68 × 28.6 mm |
| Mounting-hole diameter | 3 mm, represented as radius-1.5 layer-20 circles |
| USB centre across the board | y = 16 mm, from legacy J3 placement |
| Reset actuator centre | x = 2.4166, y = 8.1851 mm, including footprint offset |
| Flash actuator centre | x = 2.5, y = 24.532 mm, including footprint offset |

Coordinates: viewed from the component side, USB end at x=0 and UWB antenna
edge at y=0. All dimensions are millimetres.

Downloaded 2026-09-19. Source SHA-256:
`5068aaef332aa515aa8c325e9151a0ed582f79ca9226b1d13a4c6ad416c3e977`.
The original CAD retains a Micro-USB footprint and a DWM1000-labelled package
even though it is supplied in the DW3000 repository. This is evidence for the
legacy mechanical layout, not proof of the current board's full specification.

Cross-checked against the project's earlier board photo and the user's
2026-09-19 11:48:54 photo: four corner holes, header patterns, WROVER-E module,
edge-mounted UWB antenna and two buttons agree in arrangement. The photographed
outline is approximately consistent with 72 × 32.6 mm using the 2.54 mm header
pitch as a rough scale. USB-C replaces Micro-USB. Perspective and image blur
prevent metrology-grade confirmation; button locations remain adjustable.

Physical follow-up, 2026-09-19: the user confirmed a perfect fit of the printed
original `fitcheck.stl` tray on the actual board. No geometry adjustment was needed.
This validates the tray fit and mounting-hole pattern; it does not establish
the fit of features only present in the full case.

**Design assumptions, not published measurements:** PCB thickness 1.6 mm,
4 mm underside clearance, 8 mm top clearance, 4 mm V5 edge clearance, approximate
component heights, and a 16 mm wide USB cable opening. The opening runs from
2 mm below the PCB top to the lid underside (10 mm high by default). Its width
is for the cable moulding as well as the socket. Check your cable before printing.
No allowance is made for fitted pin headers or external GPIO wiring.

## Editing and exporting

Customizer `part`: `layout`, `base`, `lid`, `assembled`, `exploded`, `fitcheck`,
`test_base`, `test_lid`. Electronics are preview-only.

```sh
openscad -o exports/base-v5-internal-lip.stl -D 'part="base"' wrover-case.scad
openscad -o exports/lid-v5-internal-snap.stl -D 'part="lid"' wrover-case.scad
openscad -o exports/test-base-v5-closure.stl -D 'part="test_base"' wrover-case.scad
openscad -o exports/test-lid-v5-closure.stl -D 'part="test_lid"' wrover-case.scad
openscad -o exports/fitcheck.stl -D 'part="fitcheck"' wrover-case.scad
cp exports/base-v5-internal-lip.stl exports/base.stl
cp exports/lid-v5-internal-snap.stl exports/lid.stl
cp exports/test-base-v5-closure.stl exports/test_base.stl
cp exports/test-lid-v5-closure.stl exports/test_lid.stl
python3 verify_meshes.py
```

Diagnostic geometry uses `verify_geometry.scad` with `-D 'part="none"'` and
`-D 'check="closed"'`. The checks `closed`, `insertion`, `components`, `release`
and `allowed_play` must be empty. OpenSCAD returns exit code 1 for an empty STL;
that is expected for these negative intersections. `catch`, `locating_x` and
`locating_y` must contain material, confirming the retaining and locating stops.
