# WROVER anchor case — V4, all-PLA screwless closure

**Two printed parts. No screws, nuts, metal springs, inserts, glue or foam.**
Print a matching V4 base and lid; earlier versions are incompatible.

The board drops onto four tapered locator pins. A lift-off lid clips to the
base with two long finger-release arms. Four separate flexible sections of the
lid press hollow pads onto the PCB around its mounting holes, directly above
four base supports. These printed PLA leaves are what “springs” means here.
Their pressure is intended to prevent board movement and rattle; the pins only
locate the board and do not need a tight interference fit.

A lift-off lid allows pressure at all four corners without dragging low pads
across the radio modules, as a sliding lid would. The two latch arms flex
sideways, in the plane of the printed layers, and have broad external finger
ears. Pull the ears outwards to release them, then lift the lid.

**Physical status:** the original board footprint/pin-pattern fit check passed.
V4 is CAD-checked but has not yet been printed. Whether the board stays quiet,
the clip effort, and how well the PLA keeps its clamping pressure must be
checked on the actual print. This is not a claim of a physically proven fit.

## Print files

- `exports/base-v4-screwless.stl`: base, supports, four solid tapered pins.
- `exports/lid-v4-snap.stl`: lid, four flexible pressure pads, two snap arms.
- `exports/base.stl` and `exports/lid.stl`: aliases of those V4 files.
- `exports/test-base-v4-latch.stl` and `exports/test-lid-v4-latch.stl`:
  optional 32 mm central strips of the real case for testing both clips first.
  These test closure/release only, **not board retention**.
- `exports/test_base.stl` and `exports/test_lid.stl`: aliases of the latch samples.
- `exports/fitcheck.stl`: low tray for the board outline, supports and pins.
- `wrover-case.scad`: editable source; defaults to the two-part print layout.
- `exports/layout.png`, `base.png`, `assembled.png`, `exploded.png`: previews.
- `legacy/`: archived V2 and V3 sources and instructions. Old named exports are
  retained for existing links; they are not the new screwless parts.

Nominal body envelope: **82 × 42.6 × 17.6 mm**, plus up to 0.3 mm lid lift under
spring pressure. The release ears increase the overall width to **52.2 mm**.

## Printing and assembly

1. Print in the supplied orientation: base floor down, lid exterior face down
   with its four hollow pads pointing up. Use plain PLA, 0.2 mm layers,
   a 0.4 mm nozzle, 3 perimeters and about 20% infill. The thin flexible sections
   should be solid. Keep the 0.8 mm slots clear; do not let a brim fill them.
2. Designed for no supports. The hooks have a short 1.4 mm overhang and the
   base catch pockets have 7 mm roof bridges. Inspect these in the slicer and
   remove any strings. Ensure the arms and all four PCB leaves can flex freely.
3. Optional: print the two latch samples first. They should clip together and
   release by pulling the two ears outwards. This avoids a full print if your
   printer needs different clip clearance.
4. Unplug the board and lower it component-side up over the four pins, USB at
   the opening. It should sit flat on all four supports without forcing it.
5. Orient the lid's two button holes at the USB end. Lower it vertically.
   Its hollow pads fit over the pin tips. Press near the two clips until both
   engage. The flexible pads load the board against the base supports.
6. Check for board movement by gently shaking the case with the USB cable
   disconnected. Also check that the board remains flat and the buttons and
   socket remain usable. Recheck after the case has been closed for a day:
   sustained PLA flex can relax, so CAD clearance alone cannot prove lasting
   anti-rattle pressure.
7. To open, gently pull both broad ears away from the side walls, approximately
   1 mm, while lifting the lid. Do not pull up on the four PCB pressure leaves.

## How the retention is dimensioned

- Four locators taper from 2.5 to 1.5 mm over 3 mm. The PCB holes are 3 mm.
- Base supports and pressure pads are 5.8 mm diameter. Pad sockets are 4 mm
  diameter × 3.6 mm deep, allowing the pin tips and some pad movement to clear.
- Each PCB leaf is 20 mm from root to pad centre, 6.6 mm wide and 1.2 mm thick.
- Unloaded pads project 0.9 mm below the assumed PCB top. The clips permit
  0.3 mm lid lift, leaving **0.6 mm nominal deflection at all four pads**.
  This is deliberate spring travel, not a tight fit between rigid parts.
- The two latch arms are 26 mm long and 1.4 mm wide, with 0.6 mm hook overlap.
  Loose alignment tabs limit sideways movement independently of PCB clamping.

The preview and STLs show the **unloaded** leaves. In an assembled CAD preview,
there is consequently intentional pad overlap with the PCB. The real leaves
bend outwards when the lid closes; the preview is not a deformation simulation.
Clamping force, creep and fatigue have not been simulated or measured.

If the board rattles, first check that both hooks engaged, that the flexible
leaves are free of strings, and the PCB thickness. `board_preload` controls pad
reach; `board_spring_thickness` controls stiffness. Change those deliberately
and reprint the lid rather than making the locator pins an interference fit.
Do not globally scale either STL: that would change the known PCB hole pitch.
`clip_engagement` controls the latch overlap and closing deflection independently.

## CAD verification

OpenSCAD 2021.01 rendered the two full parts, the locator tray and both latch
samples. `verify_meshes.py` verified each as one closed manifold shell with
consistent winding, positive volume, and its lowest surface at print-bed Z=0.

`verify_geometry.scad` checks actual CSG geometry:

- No base/lid intersection in the nominal closed position.
- A clear vertical insertion path for rigid features, sampled every 1 mm
  through 12 mm of travel, excluding hooks that deliberately deflect.
- No contact between the lid and the approximate above-PCB component envelopes.
- Both hooks catch the pocket roofs when lifted beyond the allowed 0.3 mm.
- Pulling the hook ends outwards by 1.3 mm clears the base over that sampled
  opening path. This is a displaced-hook clearance check, not elastic analysis.

PCB-pad contact is intentionally excluded from rigid interference checks.
These checks do not replace the physical anti-rattle test.

## Dimension sources and cross-validation

The [Makerfabs DW3000 hardware directory](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/tree/main/hardware)
contains the [Eagle board](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.brd)
and an [electrical schematic PDF](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.pdf).
Mechanical dimensions come from the board file's layer 20, not the electrical
schematic or the dimensions of the WROVER module alone.

| Feature | Published CAD dimension |
| --- | --- |
| PCB outline | 72 × 32.6 mm |
| Mounting-hole centres | (2, 2), (70, 2), (70, 30.6), (2, 30.6) mm |
| Mounting-hole pitch | 68 × 28.6 mm |
| Mounting-hole diameter | 3 mm, represented as radius-1.5 layer-20 circles |
| USB centre across the board | y = 16 mm, from legacy J3 placement |
| Reset actuator centre | x = 2.4166, y = 8.1851 mm, including footprint offset |
| Flash actuator centre | x = 2.5, y = 24.532 mm, including footprint offset |

Coordinates: viewed from the component side, USB end at x=0 and UWB antenna
edge at y=0. All dimensions are millimetres.

Downloaded 2026-09-19. Source SHA-256:
`5068aaef332aa515aa8c325e9151a0ed582f79ca9226b1d13a4c6ad416c3e977`.
The original CAD retains a Micro-USB footprint and a DWM1000-labelled package
even though it is supplied in the DW3000 repository. This is evidence for the
legacy mechanical layout, not proof of the current board's full specification.

Cross-checked against the project's earlier board photo and the user's
2026-09-19 11:48:54 photo: four corner holes, header patterns, WROVER-E module,
edge-mounted UWB antenna and two buttons agree in arrangement. The photographed
outline is approximately consistent with 72 × 32.6 mm using the 2.54 mm header
pitch as a rough scale. USB-C replaces Micro-USB. Perspective and image blur
prevent metrology-grade confirmation; button locations remain adjustable.

Physical follow-up, 2026-09-19: the user confirmed a perfect fit of the printed
original `fitcheck.stl` tray on the actual board. No geometry adjustment was needed.
This validates the tray fit and mounting-hole pattern; it does not establish
the fit of features only present in the full case.

**Design assumptions, not published measurements:** PCB thickness 1.6 mm,
4 mm underside clearance, 8 mm top clearance, 2 mm edge clearance, approximate
component heights, and a 16 mm wide USB cable opening. The opening runs from
2 mm below the PCB top to the lid underside (10 mm high by default). Its width
is for the cable moulding as well as the socket. Check your cable before printing.
No allowance is made for fitted pin headers or external GPIO wiring.

## Editing and exporting

Customizer `part`: `layout`, `base`, `lid`, `assembled`, `exploded`, `fitcheck`,
`test_base`, `test_lid`. Electronics are preview-only.

```sh
openscad -o exports/base-v4-screwless.stl -D 'part="base"' wrover-case.scad
openscad -o exports/lid-v4-snap.stl -D 'part="lid"' wrover-case.scad
openscad -o exports/fitcheck.stl -D 'part="fitcheck"' wrover-case.scad
openscad -o exports/test_base.stl -D 'part="test_base"' wrover-case.scad
openscad -o exports/test_lid.stl -D 'part="test_lid"' wrover-case.scad
cp exports/base-v4-screwless.stl exports/base.stl
cp exports/lid-v4-snap.stl exports/lid.stl
python3 verify_meshes.py
```

Diagnostic checks use `verify_geometry.scad` with `-D 'part="none"'` and
`-D 'check="closed"'` (also `insertion`, `components`, `catch`, `release`). All
except `catch` should report an empty top-level object; OpenSCAD returns exit
code 1 for an empty STL, which is expected for these negative intersections.

The general principle of using longer flexible arms for a snap closure is
illustrated in [Formlabs' snap-fit enclosure guide](https://formlabs.com/blog/designing-3d-printed-snap-fit-enclosures/).
Its material/process-specific tolerances are not being used as PLA fit data.
