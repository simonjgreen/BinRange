# WROVER anchor case

Parametric OpenSCAD enclosure for the **Makerfabs ESP32 UWB DW3000, WROVER-E,
USB-C board** used by BinRange. The default case is **80 × 40.6 × 17.6 mm**,
with the screw heads recessed below the exterior. Base and lid print separately without supports, with
their outside faces on the bed. The model opens in this print layout.

**Status: rendered and mesh-checked; fit-check tray passed on the actual USB-C
board.** On 2026-09-19 the user reported that the fit-check print "fits perfectly".
The full base/lid assembly, cable clearance, button access, screw fit and RF
performance remain untested. The manufacturer's available CAD is an older
revision; the tray fit validates its use for this board's outline and mounting
pattern, rather than providing caliper measurements.

## Files

- `wrover-case.scad`: editable source with OpenSCAD Customizer controls.
- `exports/base.stl`: original base, unchanged by the recessed-screw revision.
- `exports/lid-m25x8-recessed.stl`: replacement lid for the blue box's M2.5 × 8 mm
  countersunk Phillips screws. `exports/lid.stl` is an identical copy.
- `exports/fitcheck.stl`: low tray with four alignment pins for a first fit test.
- `exports/exploded.png`: assembly preview; electronics are approximate envelopes.
- `sources/board-dimensions.svg` and `.png`: dimensioned drawing extracted from
  the manufacturer's PCB outline, with a separate approximate component overlay.
- `sources/board-dimensions.json`: extracted mechanical dimensions and provenance.
- `sources/makerfabs-esp32-uwb-v1.brd`: downloaded manufacturer Eagle CAD source.

## Dimension sources and cross-validation

The [Makerfabs DW3000 hardware directory](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/tree/main/hardware)
contains the [Eagle board](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.brd)
and an [electrical schematic PDF](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.pdf).
Mechanical dimensions come from the board file's layer 20, not the electrical
schematic or the dimensions of the WROVER module alone.

| Feature | Published CAD dimension |
| --- | --- |
| PCB outline | 72 × 32.6 mm |
| Mounting-hole centres | (2, 2), (70, 2), (70, 30.6), (2, 30.6) mm |
| Mounting-hole pitch | 68 × 28.6 mm |
| Mounting-hole diameter | 3 mm, represented as radius-1.5 layer-20 circles |
| USB centre across the board | y = 16 mm, from legacy J3 placement |
| Reset actuator centre | x = 2.4166, y = 8.1851 mm, including footprint offset |
| Flash actuator centre | x = 2.5, y = 24.532 mm, including footprint offset |

Coordinates: viewed from the component side, USB end at x=0 and UWB antenna
edge at y=0. All dimensions are millimetres.

Downloaded 2026-09-19. Source SHA-256:
`5068aaef332aa515aa8c325e9151a0ed582f79ca9226b1d13a4c6ad416c3e977`.
The original CAD retains a Micro-USB footprint and a DWM1000-labelled package
even though it is supplied in the DW3000 repository. This is evidence for the
legacy mechanical layout, not proof of the current board's full specification.

Cross-checked against the project's earlier board photo and the user's
2026-09-19 11:48:54 photo: four corner holes, header patterns, WROVER-E module,
edge-mounted UWB antenna and two buttons agree in arrangement. The photographed
outline is approximately consistent with 72 × 32.6 mm using the 2.54 mm header
pitch as a rough scale. USB-C replaces Micro-USB. Perspective and image blur
prevent metrology-grade confirmation; button locations remain adjustable.

Physical follow-up, 2026-09-19: the user confirmed a perfect fit of the printed
`fitcheck.stl` tray on the actual board. No geometry adjustment was needed.
This validates the tray fit and mounting-hole pattern; it does not establish
the fit of features only present in the full case.

**Design assumptions, not published measurements:** PCB thickness 1.6 mm,
4 mm underside clearance, 8 mm top clearance, 2 mm edge clearance, approximate
component heights, and a 16 mm wide USB cable opening. The opening runs from
2 mm below the PCB top to the lid underside (10 mm high by default). Its width
is for the cable moulding as well as the socket. Check your cable before printing.
No allowance is made for fitted pin headers or external GPIO wiring.

## Recessed-screw lid revision

Use **four M2.5 × 8 mm flat/countersunk Phillips screws from the blue MEIYYJ
assortment**, whose label explicitly lists that size. Only the lid needs
reprinting. The original base, its 2.1 mm pilot holes, the case height, and the
board supports are unchanged. The red ISO 7380 kit contains M2/M3/M4/M5,
but no M2.5 screws; its M2 screws are too small for these pilots, and M3 would
require changes to the base and clearance through the PCB holes.

The 8 mm screws are too short for a shallow countersink at the outer face.
Each new lid pillar instead has a **5.2 mm diameter, 6.4 mm deep access well**,
followed by a **90° countersunk seat**. The pillar is widened to **7.2 mm**
around the well and tapers to the original **5 mm** diameter at the PCB end.
This leaves 1 mm of wall around the straight well and 2.15 mm of pillar below
the conical seat. The screw heads are down inside the wells, not flush caps
filling the openings.

The reference is a [DIN 965 M2.5 × 8 mm Phillips countersunk screw](https://www.accu.co.uk/phillips-countersunk-screws/66062-SIK-M2-5-8-A4):
4.7 mm maximum head diameter, 1.5 mm head height, 90° cone and PH1 drive.
These are reference dimensions, **not measurements of the user's screws**.
The model accounts for an outer head rim as well as the cone. With those
dimensions the head top is approximately **6.25 mm below the outer lid face**,
thread engagement is **2.65 mm**, and the tip ends **3.35 mm above the case
underside**, clear of the blind-hole bottom at 1 mm. Countersunk screw length
includes the head; an 8 mm pan-head screw is not interchangeable here.

Use a slim Phillips screwdriver that can enter the 5.2 mm well; a standard
6.35 mm hex bit holder cannot enter it. Check one loose screw in the printed
lid first: its head should pass freely down the well and seat on the cone.
Do not substitute the kit's shorter M2.5 screws or the former 16 mm screw.
The shorter screws also do not work in the original unrecessed lid.

## Printing and assembly

1. Print `fitcheck.stl` with its flat face down. With the board unplugged, lower
   it over the four pins. It should rest on the four supports without force,
   with its underside components clear of the floor. Verify USB end orientation.
   This gauge checks the outline, hole pitch and underside clearance; it does
   not verify the final lid or complete cable opening.
2. If necessary adjust `pcb_length`, `pcb_width`, `hole_inset_x/y`, and
   `under_board` in OpenSCAD. Do not scale the STLs to correct hole locations.
3. Print base and lid at 0.2 mm layers, using a 0.4 mm nozzle, 3 perimeters and
   about 20% infill as a starting point. Both files sit at z=0 in print orientation;
   the lid's lip and four pillars point upwards. Use unfilled PETG or PLA for
   an indoor prototype. The 1 mm lip needs the slicer to retain thin walls.
4. Check the actual board thickness, cable moulding, button-hole alignment and
   tallest components. Dry-fit the lid; it must seat on the case rim without
   pressing on components. A 0.25 mm gap above the PCB prevents the retaining
   pillars from intentionally clamping it.
5. Use **four M2.5 × 8 mm countersunk Phillips screws**, measured from the flat
   top of the head to the tip. Drop them into the lid wells. They pass through
   the retaining pillars and existing PCB holes into the base's 2.1 mm printed
   pilot holes. If pre-forming the base threads while the board is absent,
   use a suitable tap or limit screw insertion to approximately 3 mm: do not
   drive an entire 8 mm screw into the 5 mm deep blind pilot. Remove swarf.
   During final assembly use a hand screwdriver and stop as soon as seated.
   No inserts, nuts or washers are required; pilot diameter may need tuning to
   the printer/material. Never tighten hard to pull an ill-fitting lid closed.
6. Reset/flash are accessible using a nonconductive probe through the two larger
   lid holes. The lid is removable for full access. The flat back accepts mounting
   tape; keep tape clear of the antenna regions where practical.

Default screw engagement is approximately 2.65 mm with the reference head
dimensions. Changing heights or the head profile can require a different well
depth or screw length. The model checks screw engagement, blind-hole clearance,
pillar wall thickness and material below the seat. The pilot bore leaves a
1 mm floor. The revised lid has been geometrically checked; its screw seating
and assembly on the actual hardware still need a physical check.

The case is vented and has an open USB aperture: **indoor, not weatherproof**.
Avoid metal mounting plates and conductive/carbon-filled filament around either
antenna. The project's measured orientation sensitivity means the board should
remain upright with its component face toward the coverage area. Check ranging
with the finished case installed, and recalibrate if needed; an air gap and
plastic enclosure do not guarantee unchanged antenna behaviour.

## Editing and exporting

Open the SCAD file and select `part` in Customizer:

| Mode | Result |
| --- | --- |
| `layout` | Base and inverted lid side by side on the print bed |
| `base` / `lid` | One printable part |
| `fitcheck` | Low tray with alignment pins |
| `assembled` | Closed case preview |
| `exploded` | Raised lid and approximate electronics preview |

Electronics appear only in preview modes and cannot enter STL exports.
Export individual `base` and `lid` modes, not the assembled visualization.
F5 previews; F6 renders the selected geometry.

From this directory:

```sh
openscad -o exports/base.stl -D 'part="base"' wrover-case.scad
openscad -o exports/lid.stl -D 'part="lid"' wrover-case.scad
openscad -o exports/lid-m25x8-recessed.stl -D 'part="lid"' wrover-case.scad
openscad -o exports/fitcheck.stl -D 'part="fitcheck"' wrover-case.scad
openscad -o exports/exploded.png -D 'part="exploded"' --imgsize=1400,1000 --camera=0,0,0,50,0,30,180 --autocenter --viewall --projection=o --colorscheme=Tomorrow wrover-case.scad
python3 verify_meshes.py
```

Useful tuning controls: `usb_width`, `usb_y`, `usb_bottom_offset`, `under_board`,
`above_board`, button coordinates, `pilot_d`, and `lid_clearance`. Screw wells
use `head_well_d`, `head_well_depth`, `lid_post_d`, `screw_head_d`, `screw_head_h`
and `countersink_angle`. The base's `post_d` remains separate from `lid_post_d`.
`vents=false`
removes the ventilation slots, and `button_access=false` removes the probe
holes; neither makes the USB opening weatherproof.
