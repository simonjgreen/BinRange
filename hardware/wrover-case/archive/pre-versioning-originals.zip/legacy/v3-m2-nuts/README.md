# WROVER anchor case — V3

V3 addresses the physical assembly feedback: the board now drops into corner
edge guides, is clamped onto its supports when the lid screws are snug, and
uses metal nuts instead of requiring machine screws to cut plastic threads.

**Print a new base AND lid. Use four M2 × 12 mm socket button-head screws and
four M2 hex nuts from the red CYLBAQ assortment.** No washers, tapping tools or
heat-set inserts are needed. The old M2.5 × 8 mm screws and earlier case halves
are not compatible with this revision.

Nominal assembled size remains **80 × 40.6 × 17.6 mm**. A deliberate **0.3 mm
rim seam** lets the PCB be clamped before the lid touches the case rim. The
locating lip overlaps the seam. Do not tighten until the seam disappears.

**Physical status:** the original board fit-check passed; the user subsequently
assembled V2 and reported board movement/rattle and difficult screw engagement.
V3 is a revised design awaiting physical verification. Geometric checks cannot
establish printed fit or clamping force.

V3 verification: OpenSCAD 2021.01 rendered the base, lid, low tray and both
corner samples. All five exports are single closed manifold shells with
consistent triangle winding. Boolean checks found no volumetric interference
between the case halves or board, along the screw paths, or along the nut
insertion paths. Exported contact faces give a nominal 1.6 mm PCB capture gap;
the corner samples' screw axes align after turning the lid over.

## Files

- `wrover-case.scad`: current parametric source, opens in print layout.
- `exports/base-v3-m2-nuts.stl`: new base with corner guides and side-loading nut pockets.
- `exports/lid-v3-m2-clamp.stl`: new lid with flat-bottom recessed button-head seats.
- `exports/base.stl` and `exports/lid.stl`: copies of the current V3 parts.
- `exports/test_base.stl` and `exports/test_lid.stl`: matching 14 mm corner samples
  cut from the actual parts. Test one nut/screw/PCB corner before a full print.
- `exports/fitcheck.stl`: low V3 tray with guides and nut pockets.
- `exports/layout.png`, `assembled.png`, `exploded.png`: current previews.
- `sources/board-dimensions.svg`, `.png`, `.json`: original dimension extraction.
- `legacy/v2-m25-recessed/`: archived V2 source, instructions and main STLs.
  The old `exports/lid-m25x8-recessed.stl` is also retained for existing links;
  it is **not** the V3 lid.

## What changed and why

1. **Board location:** eight short guide faces form four corner pockets, with
   0.15 mm per-edge clearance and chamfered entry faces. They engage the lower
   1 mm of the PCB edge. This keeps the board aligned during normal, base-down
   assembly without relying on screw shafts to locate it. The board is still
   removable before the lid is fitted; these are guides, not snap clips.
2. **No intentional board float:** the previous 0.25 mm gap above the PCB is
   removed. Four 5 mm diameter lid contact faces bear around the mounting holes,
   directly above the base supports. Tightening clamps the PCB in this supported
   sandwich, preventing vertical rattle and lateral sliding. The rim is 0.3 mm
   lower than the lid underside so it does not stop the clamp prematurely.
3. **Real threads:** all plastic screw passages are 2.4 mm clearance holes.
   The M2 screws engage M2 metal nuts, held against rotation by hexagonal pockets.
   The pockets open toward the centre of the case for loading with tweezers.
   Nuts are retained axially by the pocket roof and secured by the screws; before
   engagement they can slide back out, so keep the base upright during assembly.
4. **Recessed heads:** the lid has 4.4 mm diameter, 3.4 mm deep counterbores with
   flat seats for button heads. Typical 1.3 mm high heads finish 2.1 mm below
   the exterior. These are not conical countersinks.

The nut pocket is 4.4 mm across flats and 1.8 mm high by default, for an assumed
4 mm AF × 1.6 mm thick M2 nut. Its roof is at z=4.8 mm; the clamped nut occupies
z=3.2–4.8 mm. The screw tip ends at z=2.2 mm, passing through the whole nut and
leaving 1.2 mm clearance above the blind bore's bottom at z=1 mm. The roof has
1.2 mm of material below the PCB support face. All z dimensions are measured
from the case underside. Unlike countersunk screws, the M2 × 12 mm length is
measured **under the head**.

Reference dimensions, not measurements of the kit:
[Accu M2 socket button screw](https://www.accu.co.uk/socket-button-screws/8262-SSB-M2-12-A4)
(head 3.5 mm diameter × 1.3 mm high, 1.3 mm hex drive) and
[Dibolt M2 DIN 934 nut](https://dibolt.co.uk/products/m2-hexagon-full-nuts-black-stainless-steel-a2-304-din-934/)
(4 mm across flats, 1.6 mm thick). Use the key that fits the actual screw.

## Printing and assembly

1. Start with `test_base.stl` and `test_lid.stl` if possible. Print them in the
   supplied orientation. Check that an M2 nut slides fully into the side slot,
   an M2 screw slides freely through the plastic, and its head fits the lid well.
   The actual board's matching corner can sit between these samples to test the
   supported clamp; the rest of the board extends out of their cut-away sides.
   The single-corner test does not verify the full board footprint.
2. Print the new base and lid with their outside faces on the bed, pillars
   pointing up, at 0.2 mm layers with a 0.4 mm nozzle, 3 perimeters and about
   20% infill. Designed for no supports; the small nut roofs and counterbore
   shoulders require short bridges. Inspect those areas and remove strings.
3. With the board absent, load four **M2 nuts** into the inward-facing slots.
   Push each to the back of its hex pocket and check alignment through the top
   hole. Keep the case upright. The board must not conceal a partly inserted nut.
4. Lower the unplugged board between the guides, USB aligned with the case opening.
   It should rest flat on all four supports. No force is needed to locate it.
5. Put the new lid on and insert four **M2 × 12 mm button-head screws**. Start
   all four in their nuts by hand before tightening. They should rotate easily;
   if one does not, realign the nut or clear print debris rather than forcing it.
6. Tighten gradually in a diagonal pattern, only until the PCB no longer moves.
   Keep the intentional rim seam. Do not crush the plastic or bend the PCB by
   tightening hard. Check USB access and the reset/flash probe holes, then check
   ranging performance with the case fitted.

No additional spacer washers go between the PCB and the supports. If clamping
or fit is wrong, check `pcb_thickness` against the real board rather than adding
force. `guide_gap` controls lateral insertion clearance; the clamping load, not
an interference fit in the guides, prevents rattling once assembled.

The case is vented and has an open USB aperture: **indoor, not weatherproof**.
Use unfilled PLA/PETG and keep metal mounting plates away from the antennas.
The project found strong orientation sensitivity: keep the board upright with
its component face toward the coverage area. The nut/screw revision requires
an RF check; the mechanical model does not predict antenna performance.

## Dimension sources and cross-validation

The [Makerfabs DW3000 hardware directory](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/tree/main/hardware)
contains the [Eagle board](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.brd)
and an [electrical schematic PDF](https://github.com/Makerfabs/Makerfabs-ESP32-UWB-DW3000/blob/main/hardware/ESP32%20UWB%20v1.0.pdf).
Mechanical dimensions come from the board file's layer 20, not the electrical
schematic or the dimensions of the WROVER module alone.

| Feature | Published CAD dimension |
| --- | --- |
| PCB outline | 72 × 32.6 mm |
| Mounting-hole centres | (2, 2), (70, 2), (70, 30.6), (2, 30.6) mm |
| Mounting-hole pitch | 68 × 28.6 mm |
| Mounting-hole diameter | 3 mm, represented as radius-1.5 layer-20 circles |
| USB centre across the board | y = 16 mm, from legacy J3 placement |
| Reset actuator centre | x = 2.4166, y = 8.1851 mm, including footprint offset |
| Flash actuator centre | x = 2.5, y = 24.532 mm, including footprint offset |

Coordinates: viewed from the component side, USB end at x=0 and UWB antenna
edge at y=0. All dimensions are millimetres.

Downloaded 2026-09-19. Source SHA-256:
`5068aaef332aa515aa8c325e9151a0ed582f79ca9226b1d13a4c6ad416c3e977`.
The original CAD retains a Micro-USB footprint and a DWM1000-labelled package
even though it is supplied in the DW3000 repository. This is evidence for the
legacy mechanical layout, not proof of the current board's full specification.

Cross-checked against the project's earlier board photo and the user's
2026-09-19 11:48:54 photo: four corner holes, header patterns, WROVER-E module,
edge-mounted UWB antenna and two buttons agree in arrangement. The photographed
outline is approximately consistent with 72 × 32.6 mm using the 2.54 mm header
pitch as a rough scale. USB-C replaces Micro-USB. Perspective and image blur
prevent metrology-grade confirmation; button locations remain adjustable.

Physical follow-up, 2026-09-19: the user confirmed a perfect fit of the printed
original `fitcheck.stl` tray on the actual board. No geometry adjustment was needed.
This validates the tray fit and mounting-hole pattern; it does not establish
the fit of features only present in the full case.

**Design assumptions, not published measurements:** PCB thickness 1.6 mm,
4 mm underside clearance, 8 mm top clearance, 2 mm edge clearance, approximate
component heights, and a 16 mm wide USB cable opening. The opening runs from
2 mm below the PCB top to the lid underside (10 mm high by default). Its width
is for the cable moulding as well as the socket. Check your cable before printing.
No allowance is made for fitted pin headers or external GPIO wiring.

## Editing and exporting

Use Customizer `part`: `layout`, `base`, `lid`, `assembled`, `exploded`,
`fitcheck`, `test_base` or `test_lid`. Electronics are preview-only.

From this directory:

```sh
openscad -o exports/base-v3-m2-nuts.stl -D 'part="base"' wrover-case.scad
openscad -o exports/lid-v3-m2-clamp.stl -D 'part="lid"' wrover-case.scad
cp exports/base-v3-m2-nuts.stl exports/base.stl
cp exports/lid-v3-m2-clamp.stl exports/lid.stl
openscad -o exports/fitcheck.stl -D 'part="fitcheck"' wrover-case.scad
openscad -o exports/test_base.stl -D 'part="test_base"' wrover-case.scad
openscad -o exports/test_lid.stl -D 'part="test_lid"' wrover-case.scad
python3 verify_meshes.py
```

Nut fit: `nut_af`, `nut_h`, `nut_clearance_xy`, `nut_clearance_z`. Screw sliding
fit: `screw_clearance_d`. Head fit: `head_well_d`, `head_well_depth`.
PCB fit: `pcb_thickness`, `guide_gap`, `guide_height`, `under_board`, `above_board`.
`rim_relief` keeps the rim from stopping PCB clamping; it is not a PCB clearance.
Changing a fastener height or screw length requires rechecking nut engagement
and bore-bottom clearance. The source asserts those stack constraints.
