# V5.2 trial — FAILED physical test

**Both upright catches snapped at their lid roots during insertion. Retained
for history only; use the V6 redesign in `../../revisions/v6-torsion-catches/`.**

Requested experiment: each hook now engages **3 mm into the 3 mm case wall**,
so its tip is nominally flush with the exterior when the lid is centred.
This is 2 mm farther than the improved V5.1 hook. Including the existing
0.25 mm lip clearance, the projection from the tongue face is 3.25 mm.
All other geometry, including the board-pressure springs, is unchanged.

V5.1 was physically reported as a substantial improvement but still too easy
to pull off without pressing its tabs. This trial has not been physically tested.
The main source and current STL aliases remain V5.1; this experiment is separate.

## Start with the sample

- `exports/test-lid-v5-2-full-wall-trial.stl` fits the existing V5 closure-test base.
- `exports/test-base-v5-closure.stl` is that unchanged base, included for convenience.
- `exports/lid-v5-2-full-wall-trial.stl` is the full trial lid for an empty V5 base.
- `wrover-case.scad` is the self-contained trial source.

Print the small lid first. Keep the supplied exterior-face-down orientation and
use the same PLA settings as before. **Add local slicer supports under the two
flat retaining shoulders:** the new 3.25 mm horizontal overhang should not be
allowed to droop into a rounded ramp. Keep support out of the spring slots and
remove it carefully from the catch faces. The locating lip and PCB spring
geometry have not changed.

Try closing, gently pulling, and pressing both catches to release the sample.
The hook travel is much greater than before; confirm the tongues can make that
movement and return without taking a permanent set or cracking. If the sample
works, the full lid can next be checked on the empty V5 base.

## PCB clearance is not yet established

The full lid fits the unchanged V5 base in the nominal CLOSED position.
However, the conservative release test translates each tongue inward by
3.5 mm to clear the deeper hook. That envelope intersects the PCB and one
approximate component envelope. This is a clearance warning, not a simulated
bent shape: a real tongue curves and rotates instead of translating bodily.
It nevertheless means the full trial is **not validated for closing/releasing
with the electronics installed**. Test without the board first. A successful
empty-case test alone does not establish clearance with the board installed.

## Verification

OpenSCAD rendered both new lid STLs. Both are single closed manifold shells
with consistent winding, positive volume and print-bed Z=0.

In `verify_geometry.scad`, with `part="none"`:

- `closed`: empty intersection, PASS for nominal closed fit.
- `catch`: two retaining intersections, PASS for both hooks engaging.
- `release_empty_base`: empty intersection, PASS for the displaced-tongue
  envelope clearing the empty base over the sampled travel.
- `release`: nonempty PCB/component intersection, **FLAGGED**, as described above.

These are geometry checks, not a prediction of PLA bending strain, holding
force or fatigue. The 3 mm reach is a requested trial, not a proven replacement
for V5.1. Preserve the old lid while trying it.
