# V6 — full-size lid with torsion-mounted catches

**Reuse the existing V5 base. Full lid only; no small test coupon. All PLA.**

The user confirmed that both V5.2 catches broke at their bottoms where they
joined the lid during insertion. That experiment increased hook engagement
from 1 to 3 mm while retaining the same short upright flexing tabs. It demanded
much more movement from those roots. The fracture location supports that
failure mechanism; print adhesion and the exact fracture stress were not measured.
Do not use the failed 3 mm variant as the next print.

## What changed

Each new catch pivots on two horizontal torsion arms, printed flat as part of
the lid. Each arm is 20 mm long with a nominal 1.6 × 2 mm section, widening at
its connections. The intended movement is a small twist distributed along
these arms. The upright is reinforced at its root rather than serving as the
primary bending hinge.

The upright root is 2 mm thick with an inside brace. Its back tapers from
1.6 mm at mid-height to 1 mm at the tip to clear the PCB during removal.
Hook engagement is **1.5 mm**: deeper than the physically improved 1 mm version,
but below the failed 3 mm reach. The retaining face stays flat.

The base geometry is identical to V5. The four PCB spring/foot modules and
board-related dimensions are unchanged. The locating skirt is relieved along
the torsion arms; its end and corner sections still locate the lid. Nominal
latch vertical clearance remains 0.3 mm and PCB spring deflection remains 0.6 mm.

**Physical status:** CAD-checked, not yet printed. Strength, holding force,
repeated-use life and creep have not been demonstrated. This revision changes
the flexing mechanism in response to the root failure; it is not a guarantee
that a particular PLA print cannot fail.

## Files and printing

- `exports/lid-v6-torsion-catches.stl`: complete replacement lid, supplied in print orientation.
- `wrover-case.scad`: standalone editable source, defaults to the lid.
- `exports/lid-v6.png`: underside preview showing the catches and arms.
- `verify_geometry.scad`: closed, retaining, rotational and release checks.
- `verify_meshes.py`: STL manifold check.

Print exterior face down, pillars and catches up, using the same PLA and layer
settings as the successful board-retention print (0.2 mm layers, 0.4 mm nozzle
and 3 perimeters are the starting settings). The small arms should slice solid.
Do not fill their relief slots with a brim or supports.

**Use local supports under the two horizontal hook shoulders.** Their 1.75 mm
projection should retain a flat underside rather than sag into a ramp that can
pull out easily. Keep support away from the torsion arms and PCB spring slots;
remove the local support carefully after printing.

Close with the button holes at the USB end, pressing near the catches. To open,
press the hooks inward through the existing base windows while lifting the lid.
The catches should pivot together with their carriers; do not bend the upright
back and forth by hand as if it were the old flexible tab. Check retention,
release and board rattle on the actual full assembly.

## Verification performed

- OpenSCAD rendered one closed manifold STL with consistent triangle winding,
  positive volume, and minimum Z=0.
- A fresh base render matches the existing V5 base triangle geometry exactly.
- The PCB spring and foot module source is identical to the earlier lid.
- Closed base/lid geometry is clear; both hooks engage when lifted beyond the
  nominal latch clearance.
- Catch rotation from 0 to 10 degrees, sampled at 1 degree, clears the PCB and
  fixed lid. The above-PCB component-envelope check is clear.
- At 10 degrees, both catches clear the base and PCB over 0–16 mm of lift,
  sampled at 1 mm, with lateral offsets of ±0.2 mm.
- A segmented twist-envelope check for the arms clears the base from 0 to
  10 degrees, sampled at 2 degrees. This models a possible shape for clearance;
  it is not an elastic, stress or fatigue simulation.

An initial release check found contact between the catch backs and the PCB
while lifting. Tapering those backs removed the flagged interference. The
final release check is empty, unlike the earlier full-wall-depth trial.

General process background: [Prusa's modeling guidance](https://help.prusa3d.com/article/modeling-with-3d-printing-in-mind_164135)
explains why print orientation, load direction and supports affect printed
parts. This is background guidance, not a material validation of these torsion arms.

## Exporting

```sh
openscad -o exports/lid-v6-torsion-catches.stl -D 'part="lid"' wrover-case.scad
python3 verify_meshes.py
```

Use `verify_geometry.scad` with `-D 'part="none"'` and `-D 'check="closed"'`.
`catch` must contain contact geometry. `closed`, `release`, `pcb_sweep`,
`lid_sweep`, `arm_sweep` and `components` must be empty. OpenSCAD returns code
1 for an empty STL intersection; that is expected for these negative checks.
